<?php
    include_once 'dbconnect.php';
    
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $address = mysqli_real_escape_string($conn, $_POST['address']);
    $query = "INSERT INTO user (username, password, email, address) VALUES ('$username', '$password', '$email', '$address')";
    $execute = mysqli_query($conn,$query);
    
    if($execute > 0){
        echo "data user baru berhasil disimpan";
    }
    else{
        echo "data user baru gagal disimpan";
    }
    
?>