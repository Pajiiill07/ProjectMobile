<?php
include_once 'dbconnect.php';

if(isset($_POST["id"])){
	$id = $_POST["id"];
}else return;

$username = $_POST["username"];
$password = $_POST["password"];
$email = $_POST["email"];
$address = $_POST["address"];

$query = "UPDATE user SET username='$username', password='$password', email='$email', address='$address' WHERE id='$id'";

$execute = mysqli_query($conn, $query);
$arredit = [];

if ($execute) {
	$arredit["success"]="true";
	echo "Data berhasil di update";
}else{
	$arredit["success"]="false";
	echo "Data gagal di edit";
}
print(json_encode($arredit));
?>