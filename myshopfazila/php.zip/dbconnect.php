<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'id21297022_userdata');
define('DB_PASS', 'Fzl_sry07');
define('DB_NAME', 'id21297022_data');

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (mysqli_connect_errno()) {
    	echo "Failed to connect to MySQL Server" . mysqli_connect_error();
    	die();
    }
?>